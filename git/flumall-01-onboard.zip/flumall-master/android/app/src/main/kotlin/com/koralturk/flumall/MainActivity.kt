package com.koralturk.flumall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
